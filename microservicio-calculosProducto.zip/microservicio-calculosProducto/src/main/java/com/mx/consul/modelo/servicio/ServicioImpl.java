package com.mx.consul.modelo.servicio;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.mx.consul.modelo.Calcular;
import com.mx.consul.modelo.Producto;

@Service
public class ServicioImpl implements Servicio {
	
	private final RestTemplate clienteRest;


    ServicioImpl(RestTemplate clienteRest) {
        this.clienteRest = clienteRest;
    }

	
	@Override
	public List<Calcular> findAll(){
		List<Producto> productos = Arrays.asList(clienteRest.getForObject("http://localhost:8001/listar", Producto[].class));
		return productos.stream().map(p -> new Calcular(p,1)).collect(Collectors.toList());
		
	}
	

}
