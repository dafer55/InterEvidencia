package com.mx.consul.modelo.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mx.consul.modelo.Calcular;
import com.mx.consul.modelo.servicio.Servicio;

@RestController
public class Controlador {
	
	@Autowired
	private Servicio servicio;
	
	@GetMapping("/listar")
	public List<Calcular> listar(){
		return servicio.findAll();
	}
	
}
