package com.mx.consul.modelo.servicio;

import java.util.List;

import com.mx.consul.modelo.Calcular;

public interface Servicio {
	
	public List<Calcular> findAll();

}
