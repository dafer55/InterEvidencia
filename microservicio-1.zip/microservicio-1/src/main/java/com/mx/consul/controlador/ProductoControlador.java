package com.mx.consul.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import com.mx.consul.entiy.Producto;
import com.mx.consul.service.ServiceProducto;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@RestController

public class ProductoControlador {
	
	@Autowired
	private ServiceProducto productoService;
	
	@GetMapping("/listar")
	public List<Producto> Listar(){
		
		return productoService.findAll();
	}
	
	@GetMapping("/listar/{id}")
	public Producto detalle(@PathVariable Long id) {
	    return productoService.findById(id);
	}

	

}
