package com.mx.consul.service;

import java.util.List;
import com.mx.consul.entiy.Producto;

public interface ServiceProducto {
	
	public List<Producto> findAll();
	public Producto findById(Long id);
	
}
