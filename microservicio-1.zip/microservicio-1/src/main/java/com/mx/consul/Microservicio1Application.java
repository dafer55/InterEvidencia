package com.mx.consul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Microservicio1Application {

	public static void main(String[] args) {
		SpringApplication.run(Microservicio1Application.class, args);
	}

}
