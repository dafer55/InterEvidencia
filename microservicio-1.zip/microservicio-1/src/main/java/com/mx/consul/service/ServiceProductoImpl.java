package com.mx.consul.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.mx.consul.dao.DaoProducto;
import com.mx.consul.entiy.Producto;

@Service
public class ServiceProductoImpl implements ServiceProducto {
	
	@Autowired
	private DaoProducto productoDao;

	
	
	@Transactional(readOnly = true)
	public List<Producto> findAll() {

		return (List<Producto>)productoDao.findAll();
	}

	
	@Transactional(readOnly = true)
	public Producto findById(Long id) {

		return productoDao.findById(id).orElse(null);
	}

}
