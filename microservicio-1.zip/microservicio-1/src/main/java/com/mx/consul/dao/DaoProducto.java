package com.mx.consul.dao;

import org.springframework.data.repository.CrudRepository;

import com.mx.consul.entiy.Producto;

public interface DaoProducto extends CrudRepository<Producto, Long> {

}
